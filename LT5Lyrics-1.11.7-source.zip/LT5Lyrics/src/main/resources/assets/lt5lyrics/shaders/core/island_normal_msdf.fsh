#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <lt5lyrics:island.glsl>

uniform sampler2D Sampler0;

in vec2 FragCoord;
in vec2 TexCoord;
in vec4 FragColor;
in vec2 GlobalPos;

out vec4 fragColor;

float median(vec3 color) {
    return max(min(color.r, color.g), min(max(color.r, color.g), color.b));
}

void main() {
    float range = SizeSmooth.x;
    float thickness = SizeSmooth.y;
    float smoothness = SizeSmooth.z;
    float dist = median(texture(Sampler0, TexCoord).rgb) - 0.5 + thickness;
    vec2 unit = vec2(range) / vec2(textureSize(Sampler0, 0));
    vec2 screen = 1.0 / max(fwidth(TexCoord), vec2(0.000001));
    float pixels = max(0.5 * dot(unit, screen), 1.0);
    float alpha = smoothstep(-smoothness, smoothness, dist * pixels);

    // No screen-center mask: Minecraft draws its own crosshair over the world.
    vec4 color = vec4(FragColor.rgb, FragColor.a * alpha);
    if (color.a <= 0.001) discard;
    fragColor = color * ColorModulator;
}
