#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 FragCoord;
out vec2 TexCoord;
out vec4 FragColor;
out vec2 GlobalPos;

void main() {
    // The Normal 3D-only curved plate is split into quads but uses one continuous
    // 0..1 rectangle coordinate, so rounded corners are applied only to its outside.
    FragCoord = UV0;
    TexCoord = UV0;
    FragColor = Color;
    GlobalPos = Position.xy;
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
}
