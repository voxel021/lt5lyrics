package com.lt5lyrics.client.island;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import net.minecraft.client.Minecraft;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

/** Native desktop file dialogs, off the render thread. Minecraft forces AWT headless mode. */
public final class DesktopFiles {
    private static final AtomicBoolean OPEN=new AtomicBoolean();
    private DesktopFiles() {}
    public static void choose(boolean save,String title,String extension,String suggested,BiConsumer<Path,String> done) {
        Minecraft mc=Minecraft.getInstance();
        if(!OPEN.compareAndSet(false,true)){done.accept(null,"A file picker is already open.");return;}
        Thread worker=new Thread(()->{
            Path selected=null; String error=null;
            try(MemoryStack stack=MemoryStack.stackPush()){
                PointerBuffer filters=stack.mallocPointer(1); filters.put(stack.UTF8("*."+extension)).flip();
                String chosen=save?TinyFileDialogs.tinyfd_saveFileDialog(title,suggested==null?"":suggested,filters,extension.toUpperCase(Locale.ROOT)+" files")
                    :TinyFileDialogs.tinyfd_openFileDialog(title,"",filters,extension.toUpperCase(Locale.ROOT)+" files",false);
                if(chosen!=null&&!chosen.isBlank()) {
                    Path p=Path.of(chosen);
                    if(save&&!p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith("."+extension)) p=p.resolveSibling(p.getFileName()+"."+extension);
                    if(!save||!Files.exists(p)||TinyFileDialogs.tinyfd_messageBox("Confirm overwrite","Replace the existing file?","yesno","question",false))selected=p;
                }
            }catch(Throwable e){error="File picker unavailable: "+e.getClass().getSimpleName();}
            finally{OPEN.set(false);}
            Path result=selected; String problem=error; mc.execute(()->done.accept(result,problem));
        },"lt5lyrics-file-picker"); worker.setDaemon(true); worker.start();
    }
}
