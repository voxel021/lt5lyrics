#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <lt5lyrics:island.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 FragCoord;
out vec2 TexCoord;
out vec4 FragColor;
out vec2 GlobalPos;

const vec2[4] RECT_COORDS = vec2[](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

void main() {
    FragCoord = RECT_COORDS[gl_VertexID % 4];
    TexCoord = UV0;
    FragColor = Color;
    GlobalPos = Position.xy;
    vec4 clipPos = ProjMat * ModelViewMat * vec4(Position, 1.0);
    // 26.2 uses reversed depth: distant points approach zero. Preserve the
    // Sky-only far-plane clamp while leaving HUD and Normal projection alone.
    if (Extra.z > 0.5 && clipPos.w > 0.0 && clipPos.z < clipPos.w * 0.000001) {
        clipPos.z = clipPos.w * 0.000001;
    }
    gl_Position = clipPos;
}
